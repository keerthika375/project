import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search } from 'lucide-react';

const CarSearchForm = ({ onSearch, isLoading }) => {
  const [maxPrice, setMaxPrice] = useState('');
  const [minRange, setMinRange] = useState('');
  const [minTopSpeed, setMinTopSpeed] = useState('');
  const [minBatteryCapacity, setMinBatteryCapacity] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch({
      maxPrice: Number(maxPrice) || 0,
      minRange: Number(minRange) || 0,
      minTopSpeed: Number(minTopSpeed) || 0,
      minBatteryCapacity: Number(minBatteryCapacity) || 0
    });
  };

  return (
    <div style={{ maxWidth: '600px', margin: '0 auto', padding: '2.5rem', background: 'var(--surface-color)', borderRadius: '24px', border: '1px solid var(--surface-border)', backdropFilter: 'blur(10px)' }}>
      <form onSubmit={handleSubmit}>
        <div className="grid-cards" style={{ gap: '1.5rem', marginBottom: '1.5rem', gridTemplateColumns: '1fr 1fr' }}>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label htmlFor="maxPrice">Maximum Budget (₹)</label>
            <input 
              type="number" 
              id="maxPrice" 
              className="form-control" 
              placeholder="e.g. 1500000" 
              value={maxPrice} 
              onChange={(e) => setMaxPrice(e.target.value)} 
              min="0"
              step="50000"
            />
          </div>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label htmlFor="minRange">Minimum Range (km)</label>
            <input 
              type="number" 
              id="minRange" 
              className="form-control" 
              placeholder="e.g. 300" 
              value={minRange} 
              onChange={(e) => setMinRange(e.target.value)} 
              min="0"
              step="10"
            />
          </div>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label htmlFor="minTopSpeed">Min Top Speed (km/h)</label>
            <input 
              type="number" 
              id="minTopSpeed" 
              className="form-control" 
              placeholder="e.g. 120" 
              value={minTopSpeed} 
              onChange={(e) => setMinTopSpeed(e.target.value)} 
              min="0"
              step="5"
            />
          </div>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label htmlFor="minBatteryCapacity">Min Battery Size (kWh)</label>
            <input 
              type="number" 
              id="minBatteryCapacity" 
              className="form-control" 
              placeholder="e.g. 40" 
              value={minBatteryCapacity} 
              onChange={(e) => setMinBatteryCapacity(e.target.value)} 
              min="0"
              step="1"
            />
          </div>
        </div>
        
        <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem' }}>
          <motion.button 
            whileHover={!isLoading ? { scale: 1.02 } : {}}
            whileTap={!isLoading ? { scale: 0.98 } : {}}
            type="submit" 
            className="btn btn-primary cursor-pointer" 
            style={{ flex: 2, padding: '1.2rem', fontSize: '1.1rem', opacity: isLoading ? 0.7 : 1 }}
            disabled={isLoading}
          >
            {isLoading ? 'Searching...' : (
              <>Search <Search size={20} /></>
            )}
          </motion.button>

          <motion.button 
            whileHover={!isLoading ? { scale: 1.02 } : {}}
            whileTap={!isLoading ? { scale: 0.98 } : {}}
            type="button" 
            className="btn btn-outline cursor-pointer" 
            style={{ flex: 1, padding: '1.2rem', fontSize: '1.1rem' }}
            onClick={() => onSearch({ maxPrice: 0, minRange: 0, minTopSpeed: 0, minBatteryCapacity: 0 })}
            disabled={isLoading}
          >
            View All
          </motion.button>
        </div>
      </form>
    </div>
  );
};

export default CarSearchForm;
