import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Car, Battery, IndianRupee, Frown, Gauge, Zap } from 'lucide-react';

const CarResults = ({ results, searchParams }) => {
  if (!results) return null;

  if (results.length === 0) {
    return (
      <div style={{ textAlign: 'center', padding: '3rem', background: 'var(--surface-color)', borderRadius: '24px', border: '1px solid var(--surface-border)' }}>
        <Frown size={48} color="var(--text-secondary)" style={{ marginBottom: '1rem' }} />
        <h3>No Cars Found</h3>
        <p>We couldn't find any EVs matching your selected budget, range, speed, and efficiency criteria.</p>
      </div>
    );
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 }
  };

  return (
    <motion.div 
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      style={{ marginTop: '3rem' }}
    >
      <div style={{ textAlign: 'center', marginBottom: '3rem' }}>
        <h2 className="text-gradient">We Found {results.length} Match{results.length > 1 ? 'es' : ''}</h2>
        <p>Sorted by longest range</p>
      </div>

      <div className="grid-cards">
        <AnimatePresence>
          {results.map((car) => (
            <motion.div 
              key={car.id}
              variants={itemVariants} 
              layout
              style={{
                background: 'var(--surface-color)',
                padding: '2rem',
                borderRadius: '24px',
                border: '1px solid var(--surface-border)',
                backdropFilter: 'blur(10px)',
                position: 'relative',
                overflow: 'hidden'
              }}
              whileHover={{ y: -5, borderColor: 'var(--primary)', boxShadow: '0 8px 30px rgba(0, 255, 204, 0.15)' }}
            >
              <div style={{ position: 'absolute', top: 0, left: 0, padding: '0.4rem 1rem', background: 'rgba(0, 255, 204, 0.2)', color: 'var(--primary)', borderBottomRightRadius: '12px', fontWeight: 'bold', fontSize: '0.8rem' }}>
                {car.category}
              </div>
              <div style={{ textAlign: 'center', marginBottom: '1.5rem', marginTop: '1rem' }}>
                <Car size={48} color="var(--primary)" style={{ opacity: 0.8 }} />
              </div>
              <h3 style={{ fontSize: '1.4rem', marginBottom: '0.25rem', textAlign: 'center' }}>{car.make}</h3>
              <h4 style={{ color: 'var(--text-secondary)', textAlign: 'center', marginBottom: '1.5rem', fontWeight: 400 }}>{car.model}</h4>
              
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', padding: '1.5rem 0', borderTop: '1px solid var(--surface-border)', borderBottom: '1px solid var(--surface-border)', marginBottom: '1.5rem' }}>
                <div style={{ textAlign: 'center', flex: 1, borderRight: '1px solid var(--surface-border)', borderBottom: '1px solid var(--surface-border)', paddingBottom: '1rem' }}>
                  <IndianRupee size={20} color="var(--primary)" style={{ marginBottom: '0.5rem' }} />
                  <p style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: '1.2rem' }}>₹{car.price.toLocaleString('en-IN')}</p>
                </div>
                <div style={{ textAlign: 'center', flex: 1, borderBottom: '1px solid var(--surface-border)', paddingBottom: '1rem' }}>
                  <Battery size={20} color="var(--primary)" style={{ marginBottom: '0.5rem' }} />
                  <p style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: '1.2rem' }}>{car.range} km</p>
                </div>
                <div style={{ textAlign: 'center', flex: 1, borderRight: '1px solid var(--surface-border)', paddingTop: '0.5rem' }}>
                  <Gauge size={20} color="var(--primary)" style={{ marginBottom: '0.5rem' }} />
                  <p style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: '1.2rem' }}>{car.topSpeed} km/h</p>
                </div>
                <div style={{ textAlign: 'center', flex: 1, paddingTop: '0.5rem' }}>
                  <Zap size={20} color="var(--primary)" style={{ marginBottom: '0.5rem' }} />
                  <p style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: '1.2rem' }}>{car.batteryCapacity} kWh</p>
                </div>
              </div>
              
              <p style={{ textAlign: 'center', fontSize: '0.95rem' }}>{car.description}</p>
              
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default CarResults;
