import React, { useState } from 'react';
import CarSearchForm from './components/CarSearchForm';
import CarResults from './components/CarResults';
import { searchCars } from './utils/mockData';
import { CarFront } from 'lucide-react';

function App() {
  const [searchParams, setSearchParams] = useState({ maxPrice: 0, minRange: 0, minTopSpeed: 0, minBatteryCapacity: 0 });
  const [results, setResults] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSearch = async (params) => {
    setSearchParams(params);
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await fetch('http://localhost:5000/api/cars/suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      
      if (!response.ok) throw new Error("Server responded with an error");
      
      const matchedCars = await response.json();
      setResults(matchedCars);
      setHasSearched(true);
    } catch (err) {
      console.error("Failed to fetch from API", err);
      setError("Could not connect to the backend. Please ensure the server is running on port 5000.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleShowAll = () => {
    handleSearch({ maxPrice: 0, minRange: 0, minTopSpeed: 0, minBatteryCapacity: 0 });
  };

  return (
    <div className="app-container">
      <nav className="navbar">
        <div className="logo cursor-pointer" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <CarFront color="var(--primary)" size={28} />
          <span className="text-gradient">EVSuggest</span>
        </div>
        <button className="btn btn-outline cursor-pointer" onClick={() => { setHasSearched(false); setResults(null); }}>
          New Search
        </button>
      </nav>
      
      <main>
        {!hasSearched ? (
          <section className="hero-wrapper" style={{ minHeight: '80vh' }}>
            <div className="hero-bg-glow"></div>
            <div className="hero-content">
              <h1 className="hero-title">
                Find Your Perfect <span className="text-gradient">Electric Vehicle</span>
              </h1>
              <p className="hero-subtitle">
                Set your budget and range requirements below to discover the best EV matches tailored specifically for you.
              </p>
              {error && <div style={{ color: '#ff4444', marginBottom: '1rem', padding: '1rem', background: 'rgba(255,0,0,0.1)', borderRadius: '12px' }}>{error}</div>}
              <CarSearchForm onSearch={handleSearch} isLoading={isLoading} />
            </div>
          </section>
        ) : (
          <section style={{ paddingTop: '2rem' }}>
            <button className="btn btn-outline cursor-pointer" onClick={() => setHasSearched(false)} style={{ marginBottom: '2rem' }}>
              &larr; Back to Search
            </button>
            <CarResults results={results} searchParams={searchParams} />
          </section>
        )}
      </main>

      <footer className="footer" style={{ marginTop: '5rem' }}>
        <p>&copy; 2026 EVSuggest. Find your drive.</p>
      </footer>
    </div>
  );
}

export default App;
