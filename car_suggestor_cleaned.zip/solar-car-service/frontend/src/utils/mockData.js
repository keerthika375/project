export const carsData = [
  { id: '1', make: 'Tesla', model: 'Model 3 Standard Range', price: 38990, range: 272, category: 'Sedan', description: 'The electric standard.' },
  { id: '2', make: 'Tesla', model: 'Model Y Long Range', price: 47990, range: 310, category: 'SUV', description: 'Versatile family SUV.' },
  { id: '3', make: 'Hyundai', model: 'Ioniq 5 SE', price: 41800, range: 303, category: 'Hatchback', description: 'Retro-futuristic styling.' },
  { id: '4', make: 'Ford', model: 'Mustang Mach-E Select', price: 39995, range: 250, category: 'SUV', description: 'The Mustang legacy electrified.' },
  { id: '5', make: 'Chevrolet', model: 'Bolt EV', price: 26500, range: 259, category: 'Hatchback', description: 'An unbeatable budget option.' },
  { id: '6', make: 'Porsche', model: 'Taycan 4S', price: 111700, range: 235, category: 'Sedan', description: 'Luxury performance.' },
  { id: '7', make: 'Rivian', model: 'R1T Adventure', price: 73000, range: 314, category: 'Truck', description: 'Ultimate electric adventure.' }
];

export const searchCars = ({ maxPrice, minRange }) => {
  return carsData.filter(car => {
    let matchesPrice = true;
    let matchesRange = true;

    if (maxPrice > 0) {
      matchesPrice = car.price <= maxPrice;
    }
    if (minRange > 0) {
      matchesRange = car.range >= minRange;
    }

    return matchesPrice && matchesRange;
  }).sort((a, b) => b.range - a.range); // Order by highest range for best suggestions
};
