const mongoose = require('mongoose');
const Car = require('./models/Car');

const initialCars = [
  { make: 'Tata', model: 'Nexon EV Long Range', price: 1474000, range: 465, topSpeed: 140, batteryCapacity: 40.5, category: 'SUV', description: 'India’s highest-selling electric SUV.' },
  { make: 'Tata', model: 'Tiago EV', price: 799000, range: 250, topSpeed: 120, batteryCapacity: 19.2, category: 'Hatchback', description: 'The most affordable family EV.' },
  { make: 'MG', model: 'ZS EV', price: 2288000, range: 461, topSpeed: 140, batteryCapacity: 50.3, category: 'SUV', description: 'Premium tech and panoramic sunroof.' },
  { make: 'Mahindra', model: 'XUV400 EV', price: 1549000, range: 456, topSpeed: 150, batteryCapacity: 39.4, category: 'SUV', description: 'Fastest acceleration in its segment.' },
  { make: 'Hyundai', model: 'Kona Electric', price: 2384000, range: 452, topSpeed: 167, batteryCapacity: 39.2, category: 'SUV', description: 'Global design tailored for India.' },
  { make: 'BYD', model: 'Atto 3', price: 3399000, range: 521, topSpeed: 160, batteryCapacity: 60.4, category: 'SUV', description: 'Blade battery technology and premium styling.' },
  { make: 'Tata', model: 'Punch EV', price: 1099000, range: 315, topSpeed: 140, batteryCapacity: 25, category: 'Micro SUV', description: 'Compact and punchy for the city.' },
  { make: 'Tata', model: 'Tigor EV', price: 1249000, range: 315, topSpeed: 120, batteryCapacity: 26, category: 'Sedan', description: 'Safe and practical electric sedan.' },
  { make: 'Citroen', model: 'eC3', price: 1161000, range: 320, topSpeed: 107, batteryCapacity: 29.2, category: 'Hatchback', description: 'Comfortable French ride quality.' },
  { make: 'Kia', model: 'EV6 GT-Line', price: 6095000, range: 708, topSpeed: 192, batteryCapacity: 77.4, category: 'Crossover', description: 'Ultra-fast charging and futuristic performance.' },
  { make: 'Hyundai', model: 'Ioniq 5', price: 4605000, range: 631, topSpeed: 185, batteryCapacity: 72.6, category: 'SUV', description: 'Award-winning design and e-GMP platform.' },
  { make: 'MG', model: 'Comet EV', price: 699000, range: 230, topSpeed: 100, batteryCapacity: 17.3, category: 'Smart Car', description: 'Compact urban mobility for tight spaces.' },
  { make: 'Volvo', model: 'XC40 Recharge', price: 5790000, range: 418, topSpeed: 180, batteryCapacity: 78, category: 'Luxury SUV', description: 'Scandinavian safety meets electric power.' }
];

mongoose.connect('mongodb://127.0.0.1:27017/car-suggestor')
.then(async () => {
  console.log('Connected to DB. Removing existing cars...');
  await Car.deleteMany({});
  
  console.log('Seeding new EV database...');
  await Car.insertMany(initialCars);
  
  console.log('Seed successful!');
  process.exit();
}).catch(err => {
  console.error(err);
  process.exit(1);
});
