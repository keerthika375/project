const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const Car = require('./models/Car');

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// Connect to local MongoDB instance
mongoose.connect('mongodb://127.0.0.1:27017/car-suggestor')
  .then(() => console.log('Connected to MongoDB successfully!'))
  .catch((err) => console.error('MongoDB connection error:', err));

// Single endpoint for searching cars
app.post('/api/cars/suggest', async (req, res) => {
  try {
    const { maxPrice, minRange, minTopSpeed, minBatteryCapacity } = req.body;
    console.log('Incoming Search Request:', req.body);
    
    let query = {};
    
    if (maxPrice && Number(maxPrice) > 0) {
      query.price = { $lte: Number(maxPrice) };
    }
    if (minRange && Number(minRange) > 0) {
      query.range = { $gte: Number(minRange) };
    }
    if (minTopSpeed && Number(minTopSpeed) > 0) {
      query.topSpeed = { $gte: Number(minTopSpeed) };
    }
    if (minBatteryCapacity && Number(minBatteryCapacity) > 0) {
      query.batteryCapacity = { $gte: Number(minBatteryCapacity) };
    }

    console.log('Final Mongoose Query:', query);

    // Sort by descending range
    const cars = await Car.find(query).sort({ range: -1 });
    console.log(`Found ${cars.length} cars.`);
    res.json(cars);
  } catch (error) {
    console.error('Server error during car suggestion:', error);
    res.status(500).json({ error: 'Failed to fetch suggestions' });
  }
});

app.listen(PORT, () => {
  console.log(`Backend Server running locally on http://localhost:${PORT}`);
});
