const mongoose = require('mongoose');

const carSchema = new mongoose.Schema({
  make: { type: String, required: true },
  model: { type: String, required: true },
  price: { type: Number, required: true },
  range: { type: Number, required: true },
  topSpeed: { type: Number, required: true }, // km/h
  batteryCapacity: { type: Number, required: true }, // kWh
  category: { type: String, required: true },
  description: { type: String }
});

module.exports = mongoose.model('Car', carSchema);
