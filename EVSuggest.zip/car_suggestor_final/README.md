# 🚗 EVSuggest — Electric Vehicle Suggestor

A full-stack web app to help users find the best electric vehicle based on budget, range, top speed, and battery size.

## 🛠 Tech Stack

- **Frontend**: React 19 + Vite + Framer Motion + Lucide React
- **Backend**: Node.js + Express
- **Database**: MongoDB (local instance)

---

## 📋 Prerequisites

You need the following installed on your system:

| Tool | Download Link | Why |
|------|--------------|-----|
| **Node.js** (v18+) | https://nodejs.org | Runs both frontend and backend |
| **MongoDB Community** | https://www.mongodb.com/try/download/community | The database |

> **Tip:** After installing MongoDB, make sure the `mongod` service is running before starting the backend.

---

## 🚀 Setup & Run

### Step 1 — Install Backend Dependencies

```bash
cd backend
npm install
```

### Step 2 — Seed the Database (first time only)

This populates MongoDB with EV data for India.

```bash
node seed.js
```

You should see: `Seed successful!`

### Step 3 — Start the Backend Server

```bash
node server.js
```

You should see:
```
Connected to MongoDB successfully!
Backend Server running locally on http://localhost:5000
```

> Keep this terminal open.

### Step 4 — Install Frontend Dependencies (new terminal)

```bash
cd frontend
npm install
```

### Step 5 — Start the Frontend

```bash
npm run dev
```

Open your browser and go to **http://localhost:5173**

---

## 📁 Project Structure

```
car_suggestor/
├── backend/
│   ├── models/
│   │   └── Car.js          # MongoDB schema
│   ├── server.js           # Express API server
│   ├── seed.js             # Database seeder
│   └── package.json
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── CarSearchForm.jsx
│   │   │   └── CarResults.jsx
│   │   ├── utils/
│   │   │   └── mockData.js
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
│
└── README.md
```

---

## 🔌 API

**POST** `http://localhost:5000/api/cars/suggest`

**Request Body (all optional):**
```json
{
  "maxPrice": 2000000,
  "minRange": 300,
  "minTopSpeed": 120,
  "minBatteryCapacity": 30
}
```

**Response:** Array of matching EV objects, sorted by range (highest first).

---

## 🧩 Troubleshooting

| Problem | Fix |
|---------|-----|
| `MongoDB connection error` | Start MongoDB with `mongod` or start the MongoDB service |
| `Cannot connect to backend` | Make sure backend is running on port 5000 |
| `npm install` fails | Ensure Node.js v18+ is installed |
| Frontend shows blank page | Check browser console, ensure Vite is running |

### Starting MongoDB

- **Windows**: Run `mongod` in a terminal, or start the service from Services
- **macOS**: `brew services start mongodb-community` (if installed via Homebrew)
- **Linux**: `sudo systemctl start mongod`
